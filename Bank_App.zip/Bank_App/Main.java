package INTERNSHIP.Bank_App;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bank_App bank = new Bank_App();
        Scanner in = new Scanner(System.in);
        Scanner sc = new Scanner(System.in);
        Scanner db = new Scanner(System.in);
        System.out.println("Admin \n How many customers do you want to add");
        int size= in.nextInt();
        for(int i =0; i <size; i++){
            System.out.println("Enter Customer Name");
            String name = sc.nextLine();
            System.out.println("Enter Password");
            String password = sc.nextLine();
            System.out.println("Enter Balance");
            double balance  = db.nextDouble();
            bank.Add_Customer(name ,password, balance);      
        }
    System.out.println("********************************Bank Application**************************");
    System.out.println("For User \n  Do you want to logged in to application Y/N ??");
                System.out.println("--------------------------------");  
                String usr_app =sc.nextLine();
                System.out.println("--------------------------------");
    if(usr_app.equalsIgnoreCase("Y")){
        boolean loggedIn= bank.login();
        if(loggedIn){
            boolean exit = false;
            while (!exit) {
                System.out.println("*********** Enter Your Choice **********");
                System.out.println(" 1-Deposit  ");
                System.out.println(" 2-Withdraw");
                System.out.println(" 3-Check Balance ");
                System.out.println(" 4-Exit");
                int choice = in.nextInt();       
                System.out.println("*****************************************");
                 switch (choice) {
                     case 1:
                     bank.Deposit();
                         break;
                     case 2:
                     bank.Widthdraw();
                         break;
                     case 3:
                     bank.Check_Balance();
                         break;    
                     case 4:
                     System.out.println("Exiting the porgram....!!!");
                     System.out.println("**************** END *****************");
                    //  sc.close();
                    //  in.close();
                    //  db.close();
                     return;       
                     default:
                     System.out.println("Invalid choice,Please enter a correct option");
                         break;
                 }                
                }
        }
    }
    else{
        System.out.println("Exiting the porgram....!!!");
        System.out.println("**************** END *****************");
        
    }



                 sc.close();
                 in.close();
                 db.close();
        
    }    
}
