//package INTERNSHIP.Bank_App;

import java.util.ArrayList;
import java.util.Scanner;

public class Bank_App{
    private ArrayList<Customer> customers;
    private Scanner sc ;
    private Scanner db= new Scanner(System.in) ;
    private Customer logCustomer;

    public Bank_App(){
        customers = new ArrayList<Customer>();
        sc = new Scanner(System.in);
    }
    public void Add_Customer(String name ,String password, double balance){
        Customer cust= new Customer(name, password,balance);
        customers.add(cust);
        System.out.println("Customer added succesfully, Customer name = " +name);
    }
    private Customer findCustomerbyname(String name){
        for(Customer customer:customers){
            if(customer.getName().equals(name)){
                return customer;
            }
        }
        return null;
    }
    public boolean login(){
        System.out.println("Enter user name");
         String name = sc.nextLine();
        System.out.println("Enter password");
        String password = db.nextLine();
        Customer customer = findCustomerbyname(name);
        if(customer!= null && customer.getPassword().equals(password)){
            System.out.println("Logged in successfull..!!");
            logCustomer=customer;
            return true;
        }
        else{
            System.out.println("Invalid Credential found, Please Enter correct credentials ");
            return login();
    }
    }
    public void Deposit(){
        if (logCustomer!=null) {
        System.out.println("Enter Amount to deposit $");
        double amount= db.nextDouble();
        if(amount>0){
            logCustomer.setBalance(logCustomer.getBalance()+amount);
            System.out.println("Successfully Deposited $"+amount);
            
        }
        else{
            System.out.println("Deposit amount  must be positive");
        }   
    }   
}
    public void Widthdraw(){
        if (logCustomer!=null) {
        System.out.println("Enter Amount to withdraw $");
        double amount= db.nextDouble();
        if(amount>0&&amount <= logCustomer.getBalance()){
            logCustomer.setBalance(logCustomer.getBalance()-amount);
            System.out.println("Successfully withdraw $"+amount);
            
        }
        else if (amount>logCustomer.getBalance()){
            System.out.println("Indufficient funds");
        }
        else{
            System.out.println("Withdraw amount  must be positive");
        }       
    }   
}
public void Check_Balance(){
    if (logCustomer!=null) {
        System.out.println("                  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
        System.out.println("                                          \n"+logCustomer.getName()+ 
        "\n                                               Current balance is $"+logCustomer.getBalance() +"n");
        System.out.println("                  -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*");
}   
}
}